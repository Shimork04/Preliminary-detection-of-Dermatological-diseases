# skin_disease_detection_using_cnns
Using CNNs for skin disease detection

# Preliminary-Detection-of-Dermatological-diseases
A Telemedicine solution for preliminary detection of fatal skin diseases using machine learning model. 
